import React, { useEffect, useState } from 'react';
import { StatusBar, View, Text, StyleSheet } from 'react-native';
import AppNavigator from './src/navigation/AppNavigator';
import PM from './src/services/projectManager';

function App(): React.JSX.Element {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    PM.init().then(() => setReady(true));
  }, []);

  if (!ready) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>RETRO ENGINE</Text>
        <Text style={styles.loadingSub}>Loading...</Text>
      </View>
    );
  }

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#131315" />
      <AppNavigator />
    </>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 32,
    fontWeight: '900',
    color: '#f0c040',
    letterSpacing: 4,
    fontFamily: 'monospace',
  },
  loadingSub: {
    color: '#555',
    fontSize: 13,
    marginTop: 16,
    fontWeight: '700',
  },
});

export default App;
