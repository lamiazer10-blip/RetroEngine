import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet } from 'react-native';
import PM from '../services/projectManager';
import { OBJ_TYPES } from '../utils/engineData';
import { useFocusEffect } from '@react-navigation/native';

export default function ObjectEditorScreen({ navigation }) {
  const [obj, setObj] = useState(null);
  const [activeTab, setActiveTab] = useState('properties');

  useFocusEffect(
    useCallback(() => {
      const o = PM.getObject(PM.currentObjectId);
      if (o) setObj({ ...o });
      return () => {};
    }, [])
  );

  const handleSave = useCallback(() => {
    if (obj) { PM.updateObject(obj.id, obj); PM.save(); }
  }, [obj]);

  const update = useCallback((field, value) => {
    if (!obj) return;
    setObj({ ...obj, [field]: value });
  }, [obj]);

  if (!obj) {
    return (
      <View style={styles.container}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.empty}>No object selected</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => { handleSave(); navigation.goBack(); }}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{obj.name}</Text>
        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Text style={styles.saveText}>SAVE</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {['properties','appearance','physics','events'].map(t => (
          <TouchableOpacity key={t} style={[styles.tab, activeTab===t&&styles.tabActive]}
            onPress={() => setActiveTab(t)}>
            <Text style={[styles.tabText, activeTab===t&&styles.tabTextActive]}>{t.toUpperCase()}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.body}>
        {activeTab === 'properties' && (
          <>
            <PropRow label="NAME">
              <TextInput style={styles.input} value={obj.name} onChangeText={v => update('name', v)} />
            </PropRow>
            <PropRow label="TYPE">
              <View style={styles.typeGrid}>
                {OBJ_TYPES.map(t => (
                  <TouchableOpacity key={t.type} style={[styles.typeCard, obj.type===t.type&&styles.typeCardActive]}
                    onPress={() => update('type', t.type)}>
                    <Text style={styles.typeIcon}>{t.icon}</Text>
                    <Text style={styles.typeLabel}>{t.label.split(' ')[0]}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </PropRow>
            <PropRow label="WIDTH">
              <Stepper value={obj.w} onChange={v => update('w', Math.max(4, v))} />
            </PropRow>
            <PropRow label="HEIGHT">
              <Stepper value={obj.h} onChange={v => update('h', Math.max(4, v))} />
            </PropRow>
            <PropRow label="SOLID">
              <Toggle value={obj.solid} onChange={v => update('solid', v)} />
            </PropRow>
            <PropRow label="GRAVITY">
              <Toggle value={obj.gravity} onChange={v => update('gravity', v)} />
            </PropRow>
          </>
        )}

        {activeTab === 'appearance' && (
          <>
            <PropRow label="COLOR">
              <View style={{ flexDirection: 'row', gap: 4 }}>
                {['#ff4444','#44ff44','#4444ff','#ffff44','#ff44ff','#44ffff','#ffffff','#888888'].map(c => (
                  <TouchableOpacity key={c} style={[styles.colorDot, {backgroundColor:c}, obj.color===c&&styles.colorDotActive]}
                    onPress={() => update('color', c)} />
                ))}
              </View>
            </PropRow>
            <PropRow label="ANIM EFFECT">
              {['none','bob','pulse','sway','spin','squish','flicker','walk_wobble'].map(e => (
                <TouchableOpacity key={e} style={[styles.chip, obj.animEffect===e&&styles.chipActive]}
                  onPress={() => update('animEffect', e)}>
                  <Text style={[styles.chipText, obj.animEffect===e&&styles.chipTextActive]}>{e}</Text>
                </TouchableOpacity>
              ))}
            </PropRow>
          </>
        )}

        {activeTab === 'physics' && (
          <>
            <PropRow label="SPEED">
              <TextInput style={styles.inputSmall} value={String(obj.speed)} keyboardType="numeric"
                onChangeText={v => update('speed', parseFloat(v) || 0)} />
            </PropRow>
            <PropRow label="HEALTH">
              <Stepper value={obj.health} onChange={v => update('health', Math.max(0, v))} />
            </PropRow>
            <PropRow label="MAX HEALTH">
              <Stepper value={obj.maxHealth} onChange={v => update('maxHealth', Math.max(1, v))} />
            </PropRow>
            <PropRow label="ATK DAMAGE">
              <Stepper value={obj.attackDamage} onChange={v => update('attackDamage', Math.max(0, v))} />
            </PropRow>
          </>
        )}

        {activeTab === 'events' && (
          <View style={{ padding: 14 }}>
            <Text style={styles.eventIntro}>
              Events trigger actions when conditions are met (collision, input, timer, etc).
            </Text>
            <TouchableOpacity style={styles.eventAddBtn}>
              <Text style={styles.eventAddText}>+ ADD EVENT</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function PropRow({ label, children }) {
  return (
    <View style={styles.propRow}>
      <Text style={styles.propLabel}>{label}</Text>
      <View style={styles.propValue}>{children}</View>
    </View>
  );
}

function Stepper({ value, onChange }) {
  return (
    <View style={styles.stepper}>
      <TouchableOpacity onPress={() => onChange(value - 1)} style={styles.stepperBtn}>
        <Text style={styles.stepperBtnText}>−</Text>
      </TouchableOpacity>
      <Text style={styles.stepperValue}>{value}</Text>
      <TouchableOpacity onPress={() => onChange(value + 1)} style={styles.stepperBtn}>
        <Text style={styles.stepperBtnText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

function Toggle({ value, onChange }) {
  return (
    <TouchableOpacity style={[styles.toggle, value && styles.toggleOn]} onPress={() => onChange(!value)}>
      <View style={[styles.toggleKnob, value && styles.toggleKnobOn]} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 15, textTransform: 'uppercase' },
  saveButton: { backgroundColor: '#4a8f3a', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  saveText: { color: '#6dff44', fontWeight: '900', fontSize: 12 },
  tabs: { flexDirection: 'row', backgroundColor: '#131315' },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 3, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: '#f0c040', backgroundColor: '#2b2b30' },
  tabText: { color: '#888', fontWeight: '900', fontSize: 12, textTransform: 'uppercase' },
  tabTextActive: { color: '#fff' },
  body: { flex: 1 },
  propRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1e1e22', borderBottomWidth: 1, borderBottomColor: '#26262a', paddingHorizontal: 14, minHeight: 48 },
  propLabel: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 13, textTransform: 'uppercase' },
  propValue: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  input: { backgroundColor: '#333', borderRadius: 6, color: '#fff', fontWeight: '700', fontSize: 13, padding: 6, width: 140 },
  inputSmall: { backgroundColor: '#333', borderRadius: 6, color: '#fff', fontWeight: '700', fontSize: 13, padding: 6, width: 80, textAlign: 'center' },
  stepper: { flexDirection: 'row', backgroundColor: '#333', borderRadius: 6, overflow: 'hidden' },
  stepperBtn: { backgroundColor: '#1e1e22', width: 30, height: 30, justifyContent: 'center', alignItems: 'center' },
  stepperBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  stepperValue: { paddingHorizontal: 12, color: '#fff', fontWeight: '900', fontSize: 13 },
  toggle: { width: 44, height: 26, backgroundColor: '#333', borderRadius: 5, justifyContent: 'center', paddingHorizontal: 3 },
  toggleOn: { backgroundColor: '#4a8f3a' },
  toggleKnob: { width: 20, height: 20, backgroundColor: '#fff', borderRadius: 3 },
  toggleKnobOn: { alignSelf: 'flex-end' },
  typeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 4, maxWidth: 300 },
  typeCard: { backgroundColor: '#333', borderRadius: 6, padding: 4, alignItems: 'center', minWidth: 40, borderWidth: 1, borderColor: 'transparent' },
  typeCardActive: { borderColor: '#f0c040' },
  typeIcon: { fontSize: 16 },
  typeLabel: { color: '#fff', fontSize: 7, fontWeight: '700', textTransform: 'uppercase' },
  colorDot: { width: 24, height: 24, borderRadius: 4, borderWidth: 2, borderColor: '#555' },
  colorDotActive: { borderColor: '#fff' },
  chip: { backgroundColor: '#333', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4, borderWidth: 1, borderColor: '#555' },
  chipActive: { backgroundColor: '#1155cc', borderColor: '#fff' },
  chipText: { color: '#aaa', fontSize: 10, fontWeight: '700' },
  chipTextActive: { color: '#fff' },
  eventIntro: { color: '#bbb', fontSize: 12, lineHeight: 18, marginBottom: 12 },
  eventAddBtn: { backgroundColor: '#28282d', borderWidth: 1, borderColor: '#555', borderStyle: 'dashed', borderRadius: 10, padding: 14, alignItems: 'center' },
  eventAddText: { color: '#fff', fontWeight: '900', fontSize: 14, textTransform: 'uppercase' },
  empty: { color: '#aaa', textAlign: 'center', marginTop: 100, fontSize: 16 },
});
