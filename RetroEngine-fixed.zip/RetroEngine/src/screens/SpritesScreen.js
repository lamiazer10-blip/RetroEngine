import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import PM from '../services/projectManager';
import { generateSprite } from '../utils/engineData';
import { useFocusEffect } from '@react-navigation/native';

export default function SpritesScreen({ navigation }) {
  const [sprites, setSprites] = useState([]);

  useFocusEffect(
    useCallback(() => {
      const unsub = PM.subscribe(() => setSprites([...(PM.project?.sprites || [])]));
      return () => unsub();
    }, [])
  );

  const handleNew = useCallback(() => {
    const spr = generateSprite('normal');
    PM.addSprite(spr);
    PM.save();
  }, []);

  const handleOpen = useCallback((id) => {
    PM.currentSpriteId = id;
    navigation.navigate('SpriteEditor');
  }, [navigation]);

  const handleDelete = useCallback((id) => {
    Alert.alert('Delete', 'Delete this sprite?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { PM.deleteSprite(id); PM.save(); } },
    ]);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backBtnText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>SPRITES</Text>
        <TouchableOpacity style={styles.addBtn} onPress={handleNew}>
          <Text style={styles.addBtnText}>+ NEW</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={sprites}
        numColumns={3}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.grid}
        ListEmptyComponent={<Text style={styles.empty}>No sprites yet. Tap + NEW to create one.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <TouchableOpacity onPress={() => handleOpen(item.id)} style={styles.cardInner}>
              <View style={[styles.preview, { backgroundColor: '#000' }]}>
                <Text style={styles.previewText}>🖼️</Text>
              </View>
              <Text style={styles.cardLabel} numberOfLines={1}>{item.name}</Text>
              <Text style={styles.cardSize}>{item.w}×{item.h}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.delBtn} onPress={() => handleDelete(item.id)}>
              <Text style={styles.delText}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 18, textTransform: 'uppercase', letterSpacing: 1 },
  addBtn: { backgroundColor: '#4a8f3a', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  addBtnText: { color: '#6dff44', fontWeight: '900', fontSize: 12 },
  grid: { padding: 10, gap: 10 },
  card: { width: '31%', backgroundColor: '#28282d', borderRadius: 10, borderWidth: 2, borderColor: '#4a4a52', margin: '1%', position: 'relative' },
  cardInner: { alignItems: 'center', padding: 8 },
  preview: { width: 80, height: 80, borderRadius: 4, justifyContent: 'center', alignItems: 'center' },
  previewText: { fontSize: 28 },
  cardLabel: { color: '#fff', fontWeight: '900', fontSize: 10, textTransform: 'uppercase', marginTop: 4 },
  cardSize: { color: '#888', fontSize: 9 },
  delBtn: { position: 'absolute', top: 4, right: 4, backgroundColor: 'rgba(200,0,0,0.8)', borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  delText: { color: '#fff', fontSize: 10, fontWeight: '900' },
  empty: { color: '#f0c040', fontWeight: '700', fontSize: 14, textAlign: 'center', padding: 30 },
});
