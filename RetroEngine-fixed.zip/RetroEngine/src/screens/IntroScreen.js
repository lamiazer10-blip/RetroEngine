import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';

export default function IntroScreen({ navigation }) {
  const opacity = new Animated.Value(0);

  useEffect(() => {
    Animated.timing(opacity, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();

    const timer = setTimeout(() => {
      Animated.timing(opacity, {
        toValue: 0,
        duration: 400,
        useNativeDriver: true,
      }).start(() => {
        navigation.replace('MainMenu');
      });
    }, 2000);

    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.content, { opacity }]}>
        <Text style={styles.title}>RETRO{'\n'}ENGINE</Text>
        <Text style={styles.subtitle}>MOBILE GAME STUDIO</Text>
        <Text style={styles.version}>v3.0</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
  },
  title: {
    fontSize: 48,
    fontWeight: '900',
    color: '#f0c040',
    textAlign: 'center',
    letterSpacing: 6,
    fontFamily: 'monospace',
  },
  subtitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#888',
    marginTop: 16,
    letterSpacing: 3,
  },
  version: {
    fontSize: 12,
    color: '#555',
    marginTop: 24,
  },
});
