import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import * as storage from '../services/storage';
import PM from '../services/projectManager';

export default function AppSettingsScreen({ navigation }) {
  const [autoSave, setAutoSave] = useState(true);
  const [sound, setSound] = useState(true);
  const [userId, setUserId] = useState('');

  useEffect(() => {
    storage.loadAppSettings().then(s => { setAutoSave(s.autoSave); setSound(s.soundEnabled); });
    storage.getUserId().then(setUserId);
  }, []);

  const save = async (updates) => {
    const settings = { autoSave, soundEnabled: sound, ...updates };
    await storage.saveAppSettings(settings);
  };

  const handleClearData = () => {
    Alert.alert('Clear All Data', 'This will delete all projects and settings. Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: async () => {
        await storage.saveProjects([]);
        await storage.setCurrentProjectId(null);
        PM.project = null;
        PM.projects = [];
        Alert.alert('Done', 'All data cleared');
      }},
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>APP SETTINGS</Text>
      </View>
      <ScrollView style={styles.body}>
        <Text style={styles.section}>GENERAL</Text>
        <View style={styles.row}>
          <Text style={styles.lbl}>AUTO SAVE</Text>
          <Toggle value={autoSave} onChange={v => { setAutoSave(v); save({ autoSave: v }); }} />
        </View>
        <View style={styles.row}>
          <Text style={styles.lbl}>SOUND</Text>
          <Toggle value={sound} onChange={v => { setSound(v); save({ soundEnabled: v }); }} />
        </View>

        <Text style={styles.section}>ACCOUNT</Text>
        <View style={styles.row}>
          <Text style={styles.lbl}>USER ID</Text>
          <Text style={styles.val}>{userId}</Text>
        </View>

        <Text style={styles.section}>DATA</Text>
        <TouchableOpacity style={styles.dangerBtn} onPress={handleClearData}>
          <Text style={styles.dangerText}>🗑️ CLEAR ALL DATA</Text>
        </TouchableOpacity>

        <Text style={styles.about}>Retro Engine v3.0{'\n'}React Native</Text>
      </ScrollView>
    </View>
  );
}

function Toggle({ value, onChange }) {
  return (
    <TouchableOpacity style={[s.toggle, value && s.toggleOn]} onPress={() => onChange(!value)}>
      <View style={[s.toggleKnob, value && s.toggleKnobOn]} />
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  toggle: { width: 44, height: 26, backgroundColor: '#333', borderRadius: 5, justifyContent: 'center', paddingHorizontal: 3 },
  toggleOn: { backgroundColor: '#f0c040' },
  toggleKnob: { width: 20, height: 20, backgroundColor: '#fff', borderRadius: 3 },
  toggleKnobOn: { alignSelf: 'flex-end' },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase' },
  body: { flex: 1 },
  section: { color: '#f0c040', fontWeight: '900', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1, paddingHorizontal: 14, paddingTop: 16, paddingBottom: 4 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, minHeight: 48, borderBottomWidth: 1, borderBottomColor: '#333' },
  lbl: { color: '#fff', fontWeight: '900', fontSize: 14, textTransform: 'uppercase' },
  val: { color: '#f0c040', fontWeight: '900', fontSize: 14 },
  dangerBtn: { backgroundColor: '#cc2222', marginHorizontal: 14, marginTop: 14, padding: 14, borderRadius: 10, alignItems: 'center' },
  dangerText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  about: { color: '#555', fontSize: 11, textAlign: 'center', marginTop: 40, marginBottom: 30, lineHeight: 18 },
});
