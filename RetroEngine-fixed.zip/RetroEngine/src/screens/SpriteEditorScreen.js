import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

const SPR_SIZES = { tiny: 8, small: 16, normal: 32, large: 64 };
const COLORS = ['#ff0000','#ff8800','#ffff00','#88ff00','#00ff00','#00ff88','#00ffff','#0088ff','#0000ff','#8800ff','#ff00ff','#ff0088','#ffffff','#aaaaaa','#555555','#000000'];

export default function SpriteEditorScreen({ navigation }) {
  const [sprite, setSprite] = useState(null);
  const [fgColor, setFgColor] = useState('#ffffff');
  const [bgColor, setBgColor] = useState('#00000000');
  const [tool, setTool] = useState('pen');
  const [zoom, setZoom] = useState(8);

  useFocusEffect(
    useCallback(() => {
      const s = PM.getSprite(PM.currentSpriteId);
      if (s) setSprite({ ...s });
      return () => {};
    }, [])
  );

  const handleSave = useCallback(() => {
    if (sprite) { PM.updateSprite(sprite.id, sprite); PM.save(); }
  }, [sprite]);

  const handlePixelTap = useCallback((px, py) => {
    if (!sprite) return;
    const pixels = [...sprite.pixels];
    const idx = py * sprite.w + px;
    if (tool === 'pen' || tool === 'brush') {
      pixels[idx] = fgColor;
    } else if (tool === 'eraser') {
      pixels[idx] = '#00000000';
    } else if (tool === 'fill') {
      // Simple fill
      const target = pixels[idx];
      if (target === fgColor) return;
      const stack = [idx];
      while (stack.length) {
        const i = stack.pop();
        if (i < 0 || i >= pixels.length) continue;
        if (pixels[i] !== target) continue;
        pixels[i] = fgColor;
        const x = i % sprite.w, y = Math.floor(i / sprite.w);
        if (x > 0) stack.push(i - 1);
        if (x < sprite.w - 1) stack.push(i + 1);
        if (y > 0) stack.push(i - sprite.w);
        if (y < sprite.h - 1) stack.push(i + sprite.w);
      }
    }
    setSprite({ ...sprite, pixels });
  }, [sprite, tool, fgColor]);

  if (!sprite) {
    return (
      <View style={styles.container}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.empty}>No sprite selected</Text>
      </View>
    );
  }

  const cs = zoom; // cell size
  const cw = sprite.w * cs;
  const ch = sprite.h * cs;

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => { handleSave(); navigation.goBack(); }}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{sprite.name}</Text>
        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Text style={styles.saveText}>SAVE</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.body}>
        {/* Tools */}
        <View style={styles.toolPanel}>
          {['pen','eraser','fill'].map(t => (
            <TouchableOpacity key={t} style={[styles.toolBtn, tool===t&&styles.toolActive]}
              onPress={() => setTool(t)}>
              <Text style={styles.toolIcon}>{t==='pen'?'✏️':t==='eraser'?'🧹':'🪣'}</Text>
            </TouchableOpacity>
          ))}
          <View style={{ marginTop: 8 }}>
            <Text style={styles.panelLabel}>ZOOM</Text>
            <View style={{ flexDirection: 'row', gap: 4 }}>
              {[4,8,16,24].map(z => (
                <TouchableOpacity key={z} style={[styles.zoomBtn, zoom===z&&styles.zoomActive]}
                  onPress={() => setZoom(z)}>
                  <Text style={styles.zoomText}>{z}x</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          <View style={{ marginTop: 8 }}>
            <Text style={styles.panelLabel}>COLORS</Text>
            <View style={styles.colorGrid}>
              {COLORS.map(c => (
                <TouchableOpacity key={c} style={[styles.colorSwatch, {backgroundColor:c}, fgColor===c&&styles.colorActive]}
                  onPress={() => setFgColor(c)} />
              ))}
            </View>
          </View>
        </View>

        {/* Pixel Grid */}
        <ScrollView horizontal style={styles.canvasWrap} contentContainerStyle={styles.canvasInner}>
          <ScrollView>
            <View style={{ width: sprite.w * cs, height: sprite.h * cs, flexDirection: 'row', flexWrap: 'wrap' }}>
              {sprite.pixels.map((p, i) => {
                const px = i % sprite.w;
                const py = Math.floor(i / sprite.w);
                const color = p === '#00000000' ? 'transparent' : p;
                return (
                  <TouchableOpacity
                    key={i}
                    style={{ width: cs, height: cs, backgroundColor: color, borderWidth: 0.5, borderColor: 'rgba(255,255,255,0.1)' }}
                    onPress={() => handlePixelTap(px, py)}
                  />
                );
              })}
            </View>
          </ScrollView>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#26262a' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 15, textTransform: 'uppercase' },
  saveButton: { backgroundColor: '#4a8f3a', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  saveText: { color: '#6dff44', fontWeight: '900', fontSize: 12 },
  body: { flex: 1, flexDirection: 'row' },
  toolPanel: { backgroundColor: '#131315', width: 80, padding: 6, gap: 6 },
  toolBtn: { backgroundColor: '#1e1e22', width: 60, height: 44, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  toolActive: { backgroundColor: '#1155cc' },
  toolIcon: { fontSize: 18 },
  panelLabel: { color: '#aaa', fontSize: 8, fontWeight: '900', textTransform: 'uppercase', marginBottom: 3 },
  zoomBtn: { backgroundColor: '#333', paddingHorizontal: 6, paddingVertical: 3, borderRadius: 4 },
  zoomActive: { backgroundColor: '#1155cc' },
  zoomText: { color: '#fff', fontSize: 9, fontWeight: '700' },
  colorGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 2 },
  colorSwatch: { width: 16, height: 16, borderRadius: 3, borderWidth: 1, borderColor: '#555' },
  colorActive: { borderColor: '#fff', borderWidth: 2 },
  canvasWrap: { flex: 1, backgroundColor: '#4a4a52' },
  canvasInner: { justifyContent: 'center', alignItems: 'center', flexGrow: 1 },
  empty: { color: '#aaa', textAlign: 'center', marginTop: 100, fontSize: 16 },
});
