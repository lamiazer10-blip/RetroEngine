import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import PM from '../services/projectManager';
import * as storage from '../services/storage';

export default function MainMenuScreen({ navigation }) {
  const [userId, setUserId] = useState('');

  useEffect(() => {
    storage.getUserId().then(setUserId);
  }, []);

  const handleNewProject = useCallback(() => {
    navigation.navigate('CreateSelect');
  }, [navigation]);

  const handleOpenProject = useCallback(() => {
    navigation.navigate('OpenProject');
  }, [navigation]);

  const handleSettings = useCallback(() => {
    navigation.navigate('AppSettings');
  }, [navigation]);

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.exitBtn} onPress={() => {}}>
        <Text style={styles.exitText}>✕</Text>
      </TouchableOpacity>

      {userId ? (
        <View style={styles.userIdBar}>
          <Text style={styles.userIdLabel}>ID: </Text>
          <Text style={styles.userIdNum}>{userId}</Text>
        </View>
      ) : null}

      <Text style={styles.title}>RETRO ENGINE</Text>

      <View style={styles.cards}>
        <TouchableOpacity style={styles.card} onPress={handleNewProject}>
          <Text style={styles.cardIcon}>🆕</Text>
          <Text style={styles.cardLabel}>NEW PROJECT</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={handleOpenProject}>
          <Text style={styles.cardIcon}>📂</Text>
          <Text style={styles.cardLabel}>OPEN PROJECT</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.settingsBtn} onPress={handleSettings}>
        <Text style={styles.settingsText}>⚙️ Settings</Text>
      </TouchableOpacity>

      <Text style={styles.footer}>RETRO ENGINE v3.0</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1e1e22',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  exitBtn: {
    position: 'absolute',
    top: 50,
    right: 20,
    backgroundColor: '#cc2222',
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitText: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 16,
  },
  userIdBar: {
    position: 'absolute',
    top: 50,
    left: 20,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#131315',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  userIdLabel: {
    color: '#888',
    fontSize: 11,
    fontWeight: '700',
  },
  userIdNum: {
    color: '#f0c040',
    fontSize: 13,
    fontWeight: '900',
  },
  title: {
    fontSize: 36,
    fontWeight: '900',
    color: '#f0c040',
    letterSpacing: 3,
    fontFamily: 'monospace',
    marginBottom: 40,
  },
  cards: {
    flexDirection: 'row',
    gap: 16,
    width: '100%',
    maxWidth: 400,
  },
  card: {
    flex: 1,
    backgroundColor: '#6672a8',
    borderRadius: 12,
    paddingVertical: 30,
    alignItems: 'center',
  },
  cardIcon: {
    fontSize: 40,
  },
  cardLabel: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 14,
    marginTop: 10,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  settingsBtn: {
    marginTop: 40,
    backgroundColor: '#333',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 10,
  },
  settingsText: {
    color: '#aaa',
    fontWeight: '700',
    fontSize: 14,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    color: '#555',
    fontSize: 11,
    fontWeight: '700',
  },
});
