import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

export default function OpenProjectScreen({ navigation }) {
  const [projects, setProjects] = useState([]);

  useFocusEffect(
    useCallback(() => {
      setProjects([...PM.projects]);
      return () => {};
    }, [])
  );

  const handleOpen = useCallback(async (id) => {
    await PM.openProject(id);
    navigation.replace('Dashboard');
  }, [navigation]);

  const handleDelete = useCallback((id) => {
    Alert.alert('Delete', 'Delete this project?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        await PM.deleteProject(id);
        setProjects([...PM.projects]);
      }},
    ]);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>OPEN PROJECT</Text>
      </View>
      <FlatList
        data={projects}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>No saved projects. Create one first.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <TouchableOpacity style={styles.cardContent} onPress={() => handleOpen(item.id)}>
              <Text style={styles.cardName}>{item.title}</Text>
              <Text style={styles.cardMeta}>
                {(item.projectType || item.type || 'platformer').toUpperCase()} · v{item.version || 1}
              </Text>
              <Text style={styles.cardDate}>{item.updatedAt?.slice(0, 10) || ''}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.delBtn} onPress={() => handleDelete(item.id)}>
              <Text style={styles.delText}>🗑️</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase' },
  list: { padding: 14 },
  card: { backgroundColor: '#28282d', borderRadius: 10, padding: 14, marginBottom: 8, flexDirection: 'row', alignItems: 'center' },
  cardContent: { flex: 1 },
  cardName: { color: '#fff', fontWeight: '900', fontSize: 18, textTransform: 'uppercase' },
  cardMeta: { color: '#aaa', fontSize: 11, textTransform: 'uppercase', marginTop: 3 },
  cardDate: { color: '#555', fontSize: 10, marginTop: 2 },
  delBtn: { padding: 8 },
  delText: { fontSize: 18 },
  empty: { color: '#f0c040', fontWeight: '700', fontSize: 14, textAlign: 'center', padding: 30 },
});
