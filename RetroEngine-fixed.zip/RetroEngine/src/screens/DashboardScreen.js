import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

export default function DashboardScreen({ navigation }) {
  const [project, setProject] = useState(PM.project);

  useFocusEffect(
    useCallback(() => {
      const unsub = PM.subscribe((p) => setProject(p ? { ...p } : null));
      return () => unsub();
    }, [])
  );

  const handleSave = useCallback(async () => {
    await PM.save();
    Alert.alert('Saved', 'Project saved successfully');
  }, []);

  const handleExport = useCallback(() => {
    navigation.navigate('Export');
  }, [navigation]);

  const handleQuit = useCallback(() => {
    navigation.navigate('MainMenu');
  }, [navigation]);

  if (!project) {
    return (
      <View style={styles.container}>
        <Text style={styles.noProject}>No project loaded</Text>
        <TouchableOpacity style={styles.backBtn} onPress={handleQuit}>
          <Text style={styles.backText}>Back to Menu</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const ptype = project.projectType || project.type || 'platformer';
  const typeLabels = { platformer: '🏃 PLATFORMER', topdown: '🗺️ TOP DOWN', mix: '🔀 MIX' };
  const stats = PM.getStats();

  const steps = [
    { icon: '🎨', label: 'SPRITES', desc: 'Pixel art', screen: 'Sprites' },
    { icon: '🧩', label: 'OBJECTS', desc: 'Game objects', screen: 'Objects' },
    { icon: '🗺️', label: 'LEVELS', desc: 'World design', screen: 'Levels' },
  ];

  const tools = [
    { icon: '⚙️', label: 'GAME SETTINGS', desc: 'Config', screen: 'GameSettings' },
    { icon: '🎵', label: 'SONGS', desc: 'Music', screen: null },
    { icon: '📦', label: 'EXPORT', desc: 'Build', screen: 'Export' },
    { icon: '▶️', label: 'PLAY TEST', desc: 'Test', screen: 'PlaySelect' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <Text style={styles.gameName} numberOfLines={1}>
          {project.title} ({typeLabels[ptype] || ptype})
        </Text>
        <TouchableOpacity style={styles.saveBtn} onPress={handleSave}>
          <Text style={styles.saveBtnText}>💾</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quitBtn} onPress={handleQuit}>
          <Text style={styles.quitBtnText}>✕</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.contentInner}>
        <Text style={styles.sectionLabel}>BUILDING BLOCKS</Text>
        <View style={styles.stepsRow}>
          {steps.map((s, i) => (
            <TouchableOpacity key={i} style={styles.stepCard} onPress={() => navigation.navigate(s.screen)}>
              <Text style={styles.stepIcon}>{s.icon}</Text>
              <View style={styles.stepLabelBar}><Text style={styles.stepLabel}>{s.label}</Text></View>
              <Text style={styles.stepDesc}>{s.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.sectionLabel}>TOOLS</Text>
        <View style={styles.toolsRow}>
          {tools.map((t, i) => (
            <TouchableOpacity
              key={i}
              style={styles.toolCard}
              onPress={() => t.screen && navigation.navigate(t.screen)}>
              <Text style={styles.toolIcon}>{t.icon}</Text>
              <View style={styles.toolLabelBar}><Text style={styles.toolLabel}>{t.label}</Text></View>
              <Text style={styles.toolDesc}>{t.desc}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.statsBar}>
          <Text style={styles.stat}>Sprites: {stats.sprites}</Text>
          <Text style={styles.stat}>Objects: {stats.objects}</Text>
          <Text style={styles.stat}>Levels: {stats.levels}</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: {
    backgroundColor: '#131315',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    height: 56,
    gap: 8,
  },
  gameName: {
    flex: 1,
    fontSize: 15,
    fontWeight: '900',
    color: '#fff',
    textTransform: 'uppercase',
    backgroundColor: '#1a1a1a',
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  saveBtn: { backgroundColor: '#2a7a2a', width: 40, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  saveBtnText: { fontSize: 18 },
  quitBtn: { backgroundColor: '#cc2222', width: 40, height: 40, borderRadius: 10, justifyContent: 'center', alignItems: 'center' },
  quitBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  content: { flex: 1 },
  contentInner: { padding: 12, gap: 6 },
  sectionLabel: { fontSize: 11, fontWeight: '900', color: '#f0c040', letterSpacing: 1, textTransform: 'uppercase', marginTop: 4 },
  stepsRow: { flexDirection: 'row', gap: 8, height: 130 },
  stepCard: { flex: 1, backgroundColor: '#6672a8', borderRadius: 10, alignItems: 'center', paddingVertical: 10 },
  stepIcon: { fontSize: 32 },
  stepLabelBar: { backgroundColor: '#000', width: '100%', paddingVertical: 4, alignItems: 'center', marginTop: 6 },
  stepLabel: { color: '#fff', fontWeight: '900', fontSize: 11, textTransform: 'uppercase' },
  stepDesc: { color: '#bbb', fontSize: 8, textTransform: 'uppercase', marginTop: 3 },
  toolsRow: { flexDirection: 'row', gap: 8, height: 120 },
  toolCard: { flex: 1, backgroundColor: '#6a6040', borderRadius: 10, alignItems: 'center', paddingVertical: 8 },
  toolIcon: { fontSize: 28 },
  toolLabelBar: { backgroundColor: '#000', width: '100%', paddingVertical: 3, alignItems: 'center', marginTop: 4 },
  toolLabel: { color: '#fff', fontWeight: '900', fontSize: 9, textTransform: 'uppercase' },
  toolDesc: { color: '#bbb', fontSize: 7, textTransform: 'uppercase', marginTop: 2 },
  statsBar: { flexDirection: 'row', justifyContent: 'space-around', backgroundColor: '#131315', borderRadius: 8, padding: 10, marginTop: 8 },
  stat: { color: '#888', fontSize: 10, fontWeight: '700', textTransform: 'uppercase' },
  noProject: { color: '#aaa', fontSize: 16, fontWeight: '700', textAlign: 'center', marginTop: 100 },
  backBtn: { marginTop: 20, alignSelf: 'center', backgroundColor: '#1155cc', paddingHorizontal: 20, paddingVertical: 10, borderRadius: 10 },
  backText: { color: '#fff', fontWeight: '900' },
});
