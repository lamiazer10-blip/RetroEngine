import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

export default function LevelEditorScreen({ navigation }) {
  const [level, setLevel] = useState(null);
  const [activeObj, setActiveObj] = useState(null);

  useFocusEffect(
    useCallback(() => {
      const l = PM.getLevel(PM.currentLevelId);
      if (l) setLevel({ ...l });
      return () => {};
    }, [])
  );

  if (!level) {
    return (
      <View style={styles.container}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.empty}>No level selected</Text>
      </View>
    );
  }

  const objects = PM.project?.objects || [];
  const scale = Math.min(300 / level.w, 200 / level.h, 1);

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{level.name}</Text>
        <TouchableOpacity style={styles.settingsBtn} onPress={() => navigation.navigate('LevelSettings')}>
          <Text style={styles.settingsText}>⚙️</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.body}>
        {/* Object palette */}
        <View style={styles.palette}>
          <Text style={styles.paletteTitle}>OBJECTS</Text>
          {objects.map(obj => (
            <TouchableOpacity key={obj.id} style={[styles.paletteItem, activeObj===obj.id&&styles.paletteItemActive]}
              onPress={() => setActiveObj(activeObj===obj.id?null:obj.id)}>
              <View style={[styles.paletteSwatch, {backgroundColor: obj.color || '#888'}]} />
              <Text style={styles.paletteLabel} numberOfLines={1}>{obj.name}</Text>
            </TouchableOpacity>
          ))}
          {objects.length === 0 && <Text style={styles.paletteEmpty}>No objects</Text>}
        </View>

        {/* Level viewport */}
        <ScrollView style={styles.canvasWrap} contentContainerStyle={styles.canvasInner}>
          <View style={{ width: level.w * scale, height: level.h * scale, backgroundColor: level.bgColor || '#1a1a3a' }}>
            {(level.instances || []).map((inst, i) => {
              const obj = objects.find(o => o.id === inst.objId);
              return (
                <View
                  key={i}
                  style={{
                    position: 'absolute',
                    left: inst.x * scale,
                    top: inst.y * scale,
                    width: (inst.w || 32) * scale,
                    height: (inst.h || 32) * scale,
                    backgroundColor: obj?.color || '#888',
                    borderWidth: 1,
                    borderColor: 'rgba(255,255,255,0.2)',
                  }}
                />
              );
            })}
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#333' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 15, textTransform: 'uppercase' },
  settingsBtn: { backgroundColor: '#333', width: 40, height: 40, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  settingsText: { fontSize: 18 },
  body: { flex: 1, flexDirection: 'row' },
  palette: { backgroundColor: '#131315', width: 100, padding: 6, gap: 4 },
  paletteTitle: { color: '#f0c040', fontSize: 9, fontWeight: '900', textTransform: 'uppercase', marginBottom: 4 },
  paletteItem: { backgroundColor: '#1e1e22', borderRadius: 6, padding: 4, flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 2, borderColor: 'transparent' },
  paletteItemActive: { borderColor: '#f0c040' },
  paletteSwatch: { width: 20, height: 20, borderRadius: 3 },
  paletteLabel: { color: '#fff', fontSize: 9, fontWeight: '700', flex: 1, textTransform: 'uppercase' },
  paletteEmpty: { color: '#555', fontSize: 9, textAlign: 'center', padding: 10 },
  canvasWrap: { flex: 1, backgroundColor: '#111' },
  canvasInner: { justifyContent: 'center', alignItems: 'center', flexGrow: 1 },
  empty: { color: '#aaa', textAlign: 'center', marginTop: 100, fontSize: 16 },
});
