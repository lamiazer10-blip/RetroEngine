import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

export default function PlaySelectScreen({ navigation }) {
  const [levels, setLevels] = useState([]);

  useFocusEffect(
    useCallback(() => {
      setLevels([...(PM.project?.levels || [])].filter(l => l.type === 'normal' || l.type === 'main_menu'));
      return () => {};
    }, [])
  );

  const handlePlay = useCallback((id) => {
    PM.currentLevelId = id;
    navigation.navigate('PlayGame');
  }, [navigation]);

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>SELECT LEVEL</Text>
      </View>
      <FlatList
        data={levels}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>No levels to play. Create levels first.</Text>}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => handlePlay(item.id)}>
            <Text style={styles.cardName}>{item.name}</Text>
            <Text style={styles.cardMeta}>{item.w}×{item.h} · {item.instances?.length || 0} objects</Text>
            <Text style={styles.cardPlay}>▶ PLAY</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase' },
  list: { padding: 14 },
  card: { backgroundColor: '#28282d', borderRadius: 12, padding: 16, marginBottom: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardName: { color: '#fff', fontWeight: '900', fontSize: 15, textTransform: 'uppercase' },
  cardMeta: { color: '#888', fontSize: 11 },
  cardPlay: { color: '#6dff44', fontWeight: '900', fontSize: 14 },
  empty: { color: '#f0c040', fontWeight: '700', fontSize: 14, textAlign: 'center', padding: 30 },
});
