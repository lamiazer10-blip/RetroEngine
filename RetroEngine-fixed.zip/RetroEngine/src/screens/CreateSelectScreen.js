import React, { useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function CreateSelectScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>{'< Back'}</Text>
      </TouchableOpacity>

      <Text style={styles.title}>NEW PROJECT</Text>

      <View style={styles.choices}>
        <TouchableOpacity style={styles.choice} onPress={() => navigation.navigate('EnterTitle')}>
          <Text style={styles.choiceIcon}>🎮</Text>
          <Text style={styles.choiceLabel}>CREATE NEW PROJECT</Text>
          <Text style={styles.choiceDesc}>Start from scratch</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.choice} onPress={() => navigation.navigate('OpenProject')}>
          <Text style={styles.choiceIcon}>📂</Text>
          <Text style={styles.choiceLabel}>OPEN EXISTING</Text>
          <Text style={styles.choiceDesc}>Continue working</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1e1e22',
    padding: 20,
    justifyContent: 'center',
  },
  backBtn: {
    position: 'absolute',
    top: 50,
    left: 20,
    backgroundColor: '#1155cc',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  backText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: '#f0c040',
    marginBottom: 40,
    textAlign: 'center',
    letterSpacing: 2,
  },
  choices: { gap: 30 },
  choice: {
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#28282d',
    borderRadius: 14,
    borderWidth: 2,
    borderColor: '#3a3a3e',
  },
  choiceIcon: { fontSize: 48, marginBottom: 12 },
  choiceLabel: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 18,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  choiceDesc: {
    color: '#888',
    fontSize: 12,
    marginTop: 6,
  },
});
