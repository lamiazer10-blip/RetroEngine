import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

export default function GameSettingsScreen({ navigation }) {
  const [settings, setSettings] = useState(PM.getGameSettings());

  useFocusEffect(useCallback(() => {
    setSettings({ ...PM.getGameSettings() });
    return () => {};
  }, []));

  const update = (field, value) => {
    const s = { ...settings, [field]: value };
    setSettings(s);
    PM.updateGameSettings({ [field]: value });
    PM.save();
  };

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>GAME SETTINGS</Text>
      </View>
      <ScrollView style={styles.body}>
        <Row label="GRAVITY" val={settings.gravity || 0.5} onChange={v => update('gravity', v)} step={0.1} />
        <Row label="JUMP FORCE" val={settings.jumpForce || 10} onChange={v => update('jumpForce', v)} step={1} />
        <Row label="PLAYER SPEED" val={settings.playerSpeed || 2.3} onChange={v => update('playerSpeed', v)} step={0.1} />
        <Row label="GRID SIZE" val={settings.gridSize || 16} onChange={v => update('gridSize', v)} step={8} />
        <Prop label="BG COLOR">
          <View style={{ flexDirection: 'row', gap: 4 }}>
            {['#1a1a3a','#3a1a1a','#1a3a1a','#000','#333','#fff'].map(c => (
              <TouchableOpacity key={c} style={[s.dot, {backgroundColor:c}, settings.backgroundColor===c&&s.dotActive]}
                onPress={() => update('backgroundColor', c)} />
            ))}
          </View>
        </Prop>
        <Prop label="DEBUG MODE">
          <Toggle value={settings.debugMode} onChange={v => update('debugMode', v)} />
        </Prop>
      </ScrollView>
    </View>
  );
}

function Row({ label, val, onChange, step = 1 }) {
  return (
    <View style={s.row}>
      <Text style={s.lbl}>{label}</Text>
      <Stepper value={val} onChange={onChange} step={step} />
    </View>
  );
}

function Prop({ label, children }) {
  return <View style={s.row}><Text style={s.lbl}>{label}</Text>{children}</View>;
}

function Stepper({ value, onChange, step = 1 }) {
  const fmt = step < 1 ? v => v.toFixed(1) : v => String(v);
  return (
    <View style={s.step}>
      <TouchableOpacity onPress={() => onChange(Math.max(0, value - step))} style={s.stepBtn}><Text style={s.stepBtnText}>−</Text></TouchableOpacity>
      <Text style={s.stepVal}>{fmt(value)}</Text>
      <TouchableOpacity onPress={() => onChange(value + step)} style={s.stepBtn}><Text style={s.stepBtnText}>+</Text></TouchableOpacity>
    </View>
  );
}

function Toggle({ value, onChange }) {
  return (
    <TouchableOpacity style={[s.toggle, value && s.toggleOn]} onPress={() => onChange(!value)}>
      <View style={[s.toggleKnob, value && s.toggleKnobOn]} />
    </TouchableOpacity>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase' },
  body: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, minHeight: 48, backgroundColor: '#1e1e22', borderBottomWidth: 1, borderBottomColor: '#26262a' },
  lbl: { color: '#fff', fontWeight: '900', fontSize: 13, textTransform: 'uppercase' },
  step: { flexDirection: 'row', backgroundColor: '#333', borderRadius: 6, overflow: 'hidden' },
  stepBtn: { backgroundColor: '#1e1e22', width: 30, height: 30, justifyContent: 'center', alignItems: 'center' },
  stepBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  stepVal: { paddingHorizontal: 14, color: '#fff', fontWeight: '900', fontSize: 13 },
  dot: { width: 28, height: 28, borderRadius: 5, borderWidth: 2, borderColor: '#555' },
  dotActive: { borderColor: '#fff' },
  toggle: { width: 44, height: 26, backgroundColor: '#333', borderRadius: 5, justifyContent: 'center', paddingHorizontal: 3 },
  toggleOn: { backgroundColor: '#4a8f3a' },
  toggleKnob: { width: 20, height: 20, backgroundColor: '#fff', borderRadius: 3 },
  toggleKnobOn: { alignSelf: 'flex-end' },
});
