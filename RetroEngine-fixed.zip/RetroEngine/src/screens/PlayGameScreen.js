import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import PM from '../services/projectManager';

const COLORS = ['#ff0000','#ff8800','#ffff00','#88ff00','#00ff00','#00ff88','#00ffff','#0088ff','#0000ff','#8800ff','#ff00ff','#ff0088','#ffffff','#aaaaaa','#555555','#000000'];

const { width: SW, height: SH } = Dimensions.get('window');

export default function PlayGameScreen({ navigation }) {
  const [level, setLevel] = useState(null);
  const [playerPos, setPlayerPos] = useState({ x: 100, y: 300 });
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(100);

  // Load level
  React.useEffect(() => {
    const lvl = PM.getLevel(PM.currentLevelId);
    if (lvl) setLevel(lvl);
  }, []);

  const handleLeft = () => setPlayerPos(p => ({ ...p, x: p.x - 8 }));
  const handleRight = () => setPlayerPos(p => ({ ...p, x: p.x + 8 }));
  const handleJump = () => setPlayerPos(p => ({ ...p, y: p.y - 30 }));
  const handleAttack = () => {};

  if (!level) {
    return (
      <View style={styles.container}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>✕</Text>
        </TouchableOpacity>
        <Text style={styles.noLevel}>No level loaded</Text>
      </View>
    );
  }

  const scaleX = SW / level.w;
  const scaleY = SH / level.h;
  const scale = Math.min(scaleX, scaleY);

  return (
    <View style={styles.container}>
      {/* HUD */}
      <View style={styles.hud}>
        <Text style={styles.hudItem}>★ {score}</Text>
        <Text style={styles.hudItem}>♥ {health}</Text>
        <Text style={styles.hudItem}>🕹️ {level.name}</Text>
      </View>

      {/* Game Area */}
      <View style={[styles.gameArea, { backgroundColor: level.bgColor || '#1a1a3a' }]}>
        {/* Level instances */}
        {(level.instances || []).map((inst, i) => {
          const obj = PM.project?.objects?.find(o => o.id === inst.objId);
          return (
            <View
              key={i}
              style={{
                position: 'absolute',
                left: inst.x * scale,
                top: inst.y * scale,
                width: (inst.w || 32) * scale,
                height: (inst.h || 32) * scale,
                backgroundColor: obj?.color || '#666',
                borderWidth: 1,
                borderColor: 'rgba(255,255,255,0.15)',
              }}
            />
          );
        })}
        {/* Player */}
        <View
          style={{
            position: 'absolute',
            left: playerPos.x * scale,
            top: playerPos.y * scale,
            width: 32 * scale,
            height: 32 * scale,
            backgroundColor: '#3399ff',
            borderWidth: 2,
            borderColor: '#88ccff',
          }}
        />
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        <View style={styles.dpad}>
          <View style={styles.dpadRow}>
            <View style={{ width: 60 }} />
            <TouchableOpacity style={styles.dpadBtn}><Text style={styles.dpadText}>▲</Text></TouchableOpacity>
            <View style={{ width: 60 }} />
          </View>
          <View style={styles.dpadRow}>
            <TouchableOpacity style={styles.dpadBtn} onPress={handleLeft}><Text style={styles.dpadText}>◀</Text></TouchableOpacity>
            <View style={styles.dpadCenter} />
            <TouchableOpacity style={styles.dpadBtn} onPress={handleRight}><Text style={styles.dpadText}>▶</Text></TouchableOpacity>
          </View>
          <View style={styles.dpadRow}>
            <View style={{ width: 60 }} />
            <TouchableOpacity style={styles.dpadBtn}><Text style={styles.dpadText}>▼</Text></TouchableOpacity>
            <View style={{ width: 60 }} />
          </View>
        </View>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.jumpBtn} onPress={handleJump}>
            <Text style={styles.jumpText}>JUMP</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.attackBtn} onPress={handleAttack}>
            <Text style={styles.attackText}>⚔️</Text>
          </TouchableOpacity>
        </View>
      </View>

      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>✕</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  backBtn: { position: 'absolute', top: 46, right: 12, zIndex: 10, backgroundColor: '#cc2222', width: 36, height: 36, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  backText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  hud: { position: 'absolute', top: 44, left: 12, right: 50, flexDirection: 'row', gap: 12, zIndex: 10 },
  hudItem: { color: '#fff', fontWeight: '900', fontSize: 14, backgroundColor: 'rgba(0,0,0,0.45)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 5, textShadowColor: '#000', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2 },
  gameArea: { flex: 1 },
  controls: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 20, height: 160, alignItems: 'center' },
  dpad: { gap: 2 },
  dpadRow: { flexDirection: 'row', gap: 2 },
  dpadBtn: { width: 50, height: 40, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 6, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)' },
  dpadText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  dpadCenter: { width: 50, height: 40 },
  actions: { gap: 10, alignItems: 'center' },
  jumpBtn: { width: 70, height: 70, backgroundColor: 'rgba(255,180,0,0.35)', borderRadius: 35, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: 'rgba(255,180,0,0.6)' },
  jumpText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  attackBtn: { width: 55, height: 55, backgroundColor: 'rgba(255,60,60,0.35)', borderRadius: 28, justifyContent: 'center', alignItems: 'center', borderWidth: 2, borderColor: 'rgba(255,60,60,0.6)' },
  attackText: { fontSize: 20 },
  noLevel: { color: '#aaa', fontSize: 16, fontWeight: '700', textAlign: 'center', marginTop: 200 },
});
