import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import PM from '../services/projectManager';
import { generateLevel } from '../utils/engineData';
import { useFocusEffect } from '@react-navigation/native';

export default function LevelsScreen({ navigation }) {
  const [levels, setLevels] = useState([]);

  useFocusEffect(
    useCallback(() => {
      const unsub = PM.subscribe(() => setLevels([...(PM.project?.levels || [])]));
      return () => unsub();
    }, [])
  );

  const handleNew = useCallback(() => {
    const lvl = generateLevel(`Level ${(PM.project?.levels?.length || 0) + 1}`);
    PM.addLevel(lvl);
    PM.save();
  }, []);

  const handleOpen = useCallback((id) => {
    PM.currentLevelId = id;
    navigation.navigate('LevelEditor');
  }, [navigation]);

  const handleSettings = useCallback((id) => {
    PM.currentLevelId = id;
    navigation.navigate('LevelSettings');
  }, [navigation]);

  const handleDelete = useCallback((id) => {
    Alert.alert('Delete', 'Delete this level?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { PM.deleteLevel(id); PM.save(); } },
    ]);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backBtnText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>LEVELS</Text>
        <TouchableOpacity style={styles.addBtn} onPress={handleNew}>
          <Text style={styles.addBtnText}>+ NEW</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={levels}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>No levels. Tap + NEW.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <TouchableOpacity style={styles.cardContent} onPress={() => handleOpen(item.id)}>
              <Text style={styles.cardLabel}>{item.name}</Text>
              <Text style={styles.cardMeta}>{item.w}×{item.h} · {item.type}</Text>
            </TouchableOpacity>
            <View style={styles.cardActions}>
              <TouchableOpacity onPress={() => handleSettings(item.id)} style={styles.actionBtn}>
                <Text>⚙️</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDelete(item.id)} style={styles.actionBtn}>
                <Text>🗑️</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 18, textTransform: 'uppercase', letterSpacing: 1 },
  addBtn: { backgroundColor: '#4a8f3a', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  addBtnText: { color: '#6dff44', fontWeight: '900', fontSize: 12 },
  list: { padding: 10 },
  card: { backgroundColor: '#28282d', borderRadius: 10, borderWidth: 2, borderColor: '#4a4a52', flexDirection: 'row', alignItems: 'center', marginBottom: 8, padding: 12 },
  cardContent: { flex: 1 },
  cardLabel: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase' },
  cardMeta: { color: '#888', fontSize: 11, marginTop: 3 },
  cardActions: { flexDirection: 'row', gap: 8 },
  actionBtn: { padding: 6 },
  empty: { color: '#f0c040', fontWeight: '700', fontSize: 14, textAlign: 'center', padding: 30 },
});
