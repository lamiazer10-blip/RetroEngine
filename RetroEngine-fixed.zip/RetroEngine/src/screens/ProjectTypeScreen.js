import React, { useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import PM from '../services/projectManager';

const TYPES = [
  { key: 'platformer', icon: '🏃', label: 'PLATFORMER', desc: 'Side-scrolling with gravity + jump' },
  { key: 'topdown', icon: '🗺️', label: 'TOP DOWN', desc: '4-directional, no gravity' },
  { key: 'mix', icon: '🔀', label: 'MIX', desc: 'Per-level movement mode' },
];

export default function ProjectTypeScreen({ navigation }) {
  const currentType = PM._pendingProjectType || 'platformer';

  const handleSelect = useCallback((type) => {
    PM._pendingProjectType = type;
    if (PM.project) {
      PM.project.projectType = type;
      PM.project.type = type;
      PM.save();
    }
    navigation.replace('Dashboard');
  }, [navigation]);

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>{'< Back'}</Text>
      </TouchableOpacity>

      <Text style={styles.title}>CHOOSE PROJECT TYPE</Text>
      <Text style={styles.subtitle}>Select your game style</Text>

      <View style={styles.cards}>
        {TYPES.map(t => {
          const active = t.key === currentType;
          return (
            <TouchableOpacity
              key={t.key}
              style={[styles.card, active && styles.cardActive]}
              onPress={() => handleSelect(t.key)}>
              <Text style={styles.cardIcon}>{t.icon}</Text>
              <View style={styles.cardBody}>
                <Text style={styles.cardLabel}>{t.label}</Text>
                <Text style={styles.cardDesc}>{t.desc}</Text>
              </View>
              {active && <Text style={styles.cardBadge}>✓</Text>}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22', padding: 20, justifyContent: 'center' },
  backBtn: { position: 'absolute', top: 50, left: 20, backgroundColor: '#1155cc', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  title: { textAlign: 'center', fontSize: 24, fontWeight: '900', color: '#f0c040', letterSpacing: 2, marginBottom: 8 },
  subtitle: { textAlign: 'center', fontSize: 13, color: '#888', marginBottom: 30 },
  cards: { gap: 14 },
  card: {
    backgroundColor: '#131315',
    borderWidth: 2,
    borderColor: '#1e1e22',
    borderRadius: 14,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  cardActive: { borderColor: '#f0c040', backgroundColor: '#2a2a1a' },
  cardIcon: { fontSize: 36 },
  cardBody: { flex: 1 },
  cardLabel: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase', letterSpacing: 1 },
  cardDesc: { color: '#888', fontSize: 11, marginTop: 4 },
  cardBadge: { color: '#f0c040', fontWeight: '900', fontSize: 18 },
});
