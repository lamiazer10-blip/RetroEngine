import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet } from 'react-native';
import PM from '../services/projectManager';
import { useFocusEffect } from '@react-navigation/native';

export default function LevelSettingsScreen({ navigation }) {
  const [level, setLevel] = useState(null);

  useFocusEffect(
    useCallback(() => {
      const l = PM.getLevel(PM.currentLevelId);
      if (l) setLevel({ ...l });
      return () => {};
    }, [])
  );

  if (!level) {
    return (
      <View style={styles.container}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.empty}>No level selected</Text>
      </View>
    );
  }

  const update = (field, value) => { setLevel({ ...level, [field]: value }); PM.updateLevel(level.id, { [field]: value }); };

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>LEVEL SETTINGS</Text>
      </View>
      <ScrollView style={styles.body}>
        <PropRow label="NAME">
          <TextInput style={styles.input} value={level.name} onChangeText={v => update('name', v)} />
        </PropRow>
        <PropRow label="TYPE">
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {['normal','main_menu'].map(t => (
              <TouchableOpacity key={t} style={[styles.chip, level.type===t&&styles.chipActive]}
                onPress={() => update('type', t)}>
                <Text style={[styles.chipText, level.type===t&&styles.chipActiveText]}>{t}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </PropRow>
        <PropRow label="WIDTH">
          <Stepper value={level.w} onChange={v => update('w', Math.max(64, v))} />
        </PropRow>
        <PropRow label="HEIGHT">
          <Stepper value={level.h} onChange={v => update('h', Math.max(64, v))} />
        </PropRow>
        <PropRow label="BG COLOR">
          <View style={{ flexDirection: 'row', gap: 4 }}>
            {['#1a1a3a','#3a1a1a','#1a3a1a','#000000','#333333','#ffffff'].map(c => (
              <TouchableOpacity key={c} style={[styles.colorDot, {backgroundColor:c}, level.bgColor===c&&styles.colorActive]}
                onPress={() => update('bgColor', c)} />
            ))}
          </View>
        </PropRow>
        <PropRow label="GRADIENT">
          <Toggle value={level.bgGradient} onChange={v => update('bgGradient', v)} />
        </PropRow>
        <Text style={styles.sectionHdr}>LIGHTING</Text>
        <PropRow label="ENABLED">
          <Toggle value={level.lighting?.enabled} onChange={v => update('lighting', {...level.lighting, enabled: v})} />
        </PropRow>
        <PropRow label="DARKNESS">
          <Stepper value={level.lighting?.darkness||70} onChange={v => update('lighting', {...level.lighting, darkness: v})} />
        </PropRow>
      </ScrollView>
    </View>
  );
}

function PropRow({ label, children }) {
  return <View style={styles.propRow}><Text style={styles.propLabel}>{label}</Text><View>{children}</View></View>;
}
function Stepper({ value, onChange }) {
  return (
    <View style={styles.stepper}>
      <TouchableOpacity onPress={() => onChange(value - 1)} style={styles.stepperBtn}><Text style={styles.stepperBtnText}>−</Text></TouchableOpacity>
      <Text style={styles.stepperValue}>{value}</Text>
      <TouchableOpacity onPress={() => onChange(value + 1)} style={styles.stepperBtn}><Text style={styles.stepperBtnText}>+</Text></TouchableOpacity>
    </View>
  );
}
function Toggle({ value, onChange }) {
  return (
    <TouchableOpacity style={[styles.toggle, value && styles.toggleOn]} onPress={() => onChange(!value)}>
      <View style={[styles.toggleKnob, value && styles.toggleKnobOn]} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { color: '#fff', fontWeight: '900', fontSize: 16, textTransform: 'uppercase' },
  body: { flex: 1 },
  propRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#1e1e22', borderBottomWidth: 1, borderBottomColor: '#26262a', paddingHorizontal: 14, minHeight: 48 },
  propLabel: { color: '#fff', fontWeight: '900', fontSize: 13, textTransform: 'uppercase' },
  input: { backgroundColor: '#333', borderRadius: 6, color: '#fff', fontWeight: '700', fontSize: 13, padding: 6, width: 140 },
  chip: { backgroundColor: '#333', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6, borderWidth: 1, borderColor: '#555' },
  chipActive: { backgroundColor: '#1155cc', borderColor: '#fff' },
  chipText: { color: '#aaa', fontSize: 11, fontWeight: '700', textTransform: 'uppercase' },
  chipActiveText: { color: '#fff' },
  colorDot: { width: 28, height: 28, borderRadius: 5, borderWidth: 2, borderColor: '#555' },
  colorActive: { borderColor: '#fff' },
  stepper: { flexDirection: 'row', backgroundColor: '#333', borderRadius: 6, overflow: 'hidden' },
  stepperBtn: { backgroundColor: '#1e1e22', width: 30, height: 30, justifyContent: 'center', alignItems: 'center' },
  stepperBtnText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  stepperValue: { paddingHorizontal: 12, color: '#fff', fontWeight: '900', fontSize: 13 },
  toggle: { width: 44, height: 26, backgroundColor: '#333', borderRadius: 5, justifyContent: 'center', paddingHorizontal: 3 },
  toggleOn: { backgroundColor: '#4a8f3a' },
  toggleKnob: { width: 20, height: 20, backgroundColor: '#fff', borderRadius: 3 },
  toggleKnobOn: { alignSelf: 'flex-end' },
  sectionHdr: { backgroundColor: '#2a6a2a', color: '#fff', fontWeight: '900', fontSize: 13, textTransform: 'uppercase', paddingVertical: 10, paddingHorizontal: 14, marginTop: 4 },
  empty: { color: '#aaa', textAlign: 'center', marginTop: 100, fontSize: 16 },
});
