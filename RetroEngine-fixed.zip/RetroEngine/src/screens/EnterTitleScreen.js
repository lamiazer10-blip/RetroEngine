import React, { useState, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import PM from '../services/projectManager';

export default function EnterTitleScreen({ navigation }) {
  const [title, setTitle] = useState('');

  const handleContinue = useCallback(async () => {
    const t = title.trim();
    if (!t) { return; }
    await PM.createProject(t);
    navigation.navigate('ProjectType');
  }, [title, navigation]);

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backText}>{'< Back'}</Text>
      </TouchableOpacity>

      <View style={styles.form}>
        <Text style={styles.label}>ENTER PROJECT TITLE</Text>
        <TextInput
          style={styles.input}
          value={title}
          onChangeText={setTitle}
          placeholder="My Awesome Game"
          placeholderTextColor="#555"
          autoFocus
          maxLength={40}
        />
        <TouchableOpacity
          style={[styles.okBtn, !title.trim() && styles.okBtnDisabled]}
          onPress={handleContinue}
          disabled={!title.trim()}>
          <Text style={styles.okText}>OK</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1e1e22',
    padding: 20,
    justifyContent: 'center',
  },
  backBtn: {
    position: 'absolute',
    top: 50,
    left: 20,
    backgroundColor: '#1155cc',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  backText: { color: '#fff', fontWeight: '900', fontSize: 14 },
  form: { alignItems: 'center', gap: 20 },
  label: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 16,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  input: {
    width: '100%',
    maxWidth: 400,
    height: 52,
    backgroundColor: '#7a8060',
    borderRadius: 10,
    paddingHorizontal: 16,
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  okBtn: {
    backgroundColor: '#fff',
    borderRadius: 14,
    paddingHorizontal: 60,
    paddingVertical: 14,
    marginTop: 24,
  },
  okBtnDisabled: { opacity: 0.4 },
  okText: {
    color: '#000',
    fontWeight: '900',
    fontSize: 20,
    textTransform: 'uppercase',
  },
});
