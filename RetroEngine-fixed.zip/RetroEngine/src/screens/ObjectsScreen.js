import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import PM from '../services/projectManager';
import { generateObject } from '../utils/engineData';
import { useFocusEffect } from '@react-navigation/native';

export default function ObjectsScreen({ navigation }) {
  const [objects, setObjects] = useState([]);

  useFocusEffect(
    useCallback(() => {
      const unsub = PM.subscribe(() => setObjects([...(PM.project?.objects || [])]));
      return () => unsub();
    }, [])
  );

  const handleNew = useCallback(() => {
    const obj = generateObject('solid');
    PM.addObject(obj);
    PM.save();
  }, []);

  const handleOpen = useCallback((id) => {
    PM.currentObjectId = id;
    navigation.navigate('ObjectEditor');
  }, [navigation]);

  const handleDelete = useCallback((id) => {
    Alert.alert('Delete', 'Delete this object?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { PM.deleteObject(id); PM.save(); } },
    ]);
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.topbar}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backBtnText}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.title}>OBJECTS</Text>
        <TouchableOpacity style={styles.addBtn} onPress={handleNew}>
          <Text style={styles.addBtnText}>+ NEW</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={objects}
        numColumns={3}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.grid}
        ListEmptyComponent={<Text style={styles.empty}>No objects. Tap + NEW.</Text>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <TouchableOpacity onPress={() => handleOpen(item.id)} style={styles.cardInner}>
              <View style={styles.preview}>
                <Text style={styles.previewIcon}>🧩</Text>
              </View>
              <Text style={styles.cardLabel} numberOfLines={1}>{item.name}</Text>
              <Text style={styles.cardType}>{item.type}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.delBtn} onPress={() => handleDelete(item.id)}>
              <Text style={styles.delText}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1e1e22' },
  topbar: { backgroundColor: '#131315', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, height: 56, gap: 8 },
  backBtn: { backgroundColor: '#1155cc', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  backBtnText: { color: '#fff', fontWeight: '900', fontSize: 12 },
  title: { flex: 1, color: '#fff', fontWeight: '900', fontSize: 18, textTransform: 'uppercase', letterSpacing: 1 },
  addBtn: { backgroundColor: '#4a8f3a', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  addBtnText: { color: '#6dff44', fontWeight: '900', fontSize: 12 },
  grid: { padding: 10 },
  card: { width: '31%', backgroundColor: '#28282d', borderRadius: 10, borderWidth: 2, borderColor: '#4a4a52', margin: '1%' },
  cardInner: { alignItems: 'center', padding: 8 },
  preview: { width: 80, height: 70, backgroundColor: '#111', borderRadius: 4, justifyContent: 'center', alignItems: 'center' },
  previewIcon: { fontSize: 28 },
  cardLabel: { color: '#fff', fontWeight: '900', fontSize: 10, textTransform: 'uppercase', marginTop: 4 },
  cardType: { color: '#888', fontSize: 8, textTransform: 'uppercase' },
  delBtn: { position: 'absolute', top: 4, right: 4, backgroundColor: 'rgba(200,0,0,0.8)', borderRadius: 4, paddingHorizontal: 5, paddingVertical: 2 },
  delText: { color: '#fff', fontSize: 10, fontWeight: '900' },
  empty: { color: '#f0c040', fontWeight: '700', fontSize: 14, textAlign: 'center', padding: 30 },
});
