// Constants and data definitions migrated from the web engine

export const SPR_SIZES = {
  tiny: { w: 8, h: 8 },
  small: { w: 16, h: 16 },
  normal: { w: 32, h: 32 },
  large: { w: 64, h: 64 },
};

export const OBJ_TYPES = [
  { type: 'button', label: 'BUTTON', icon: '🔘', cat: 'ui' },
  { type: 'popup_text', label: 'POPUP TEXT', icon: '💬', cat: 'ui' },
  { type: 'timer', label: 'TIMER', icon: '⏱', cat: 'hud' },
  { type: 'text', label: 'TEXT', icon: 'T', cat: 'hud' },
  { type: 'score', label: 'SCORE', icon: '★', cat: 'hud' },
  { type: 'health', label: 'HEALTH', icon: '♥', cat: 'hud' },
  { type: 'player', label: 'PLAYER', icon: '🧑', cat: 'actor' },
  { type: 'enemy', label: 'ENEMY', icon: '👾', cat: 'actor' },
  { type: 'monster', label: 'MONSTER', icon: '🐲', cat: 'actor' },
  { type: 'npc', label: 'NPC', icon: '🧙', cat: 'actor' },
  { type: 'collectable', label: 'COLLECTABLE', icon: '💎', cat: 'item' },
  { type: 'powerup', label: 'POWER UP', icon: '⚡', cat: 'item' },
  { type: 'solid', label: 'SOLID', icon: '🧱', cat: 'world' },
  { type: 'platform', label: 'PLATFORM', icon: '🪜', cat: 'world' },
  { type: 'design', label: 'DESIGN', icon: '🎨', cat: 'world' },
  { type: 'light', label: 'LIGHT', icon: '💡', cat: 'world' },
  { type: 'door', label: 'DOOR', icon: '🚪', cat: 'world' },
  { type: 'trigger', label: 'TRIGGER', icon: '🎯', cat: 'world' },
];

export const DEFAULT_COLORS = [
  '#ff0000','#ff8800','#ffff00','#88ff00','#00ff00',
  '#00ff88','#00ffff','#0088ff','#0000ff','#8800ff',
  '#ff00ff','#ff0088','#ffffff','#aaaaaa','#555555','#000000',
];

export const PROJECT_TYPES = {
  platformer: { label: 'PLATFORMER', gravity: 0.5, jumpForce: 10 },
  topdown: { label: 'TOP DOWN', gravity: 0, jumpForce: 0 },
  mix: { label: 'MIX', gravity: 0.5, jumpForce: 10 },
};

export function generateId() {
  return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
}

export function generateProject() {
  const now = new Date().toISOString();
  return {
    id: generateId(),
    title: 'My Game',
    type: 'platformer',
    projectType: 'platformer',
    createdAt: now,
    updatedAt: now,
    version: 1,
    gameSettings: {
      gravity: 0.5,
      jumpForce: 10,
      playerSpeed: 2.3,
      cameraMode: 'follow',
      gridSize: 16,
      backgroundColor: '#1a1a3a',
      debugMode: false,
    },
    sprites: [],
    objects: [],
    levels: [],
    songs: [],
    cutscenes: [],
    exportSettings: {
      gameName: 'My Game',
      packageName: 'com.studio.mygame',
      versionName: '1.0.0',
      versionCode: 1,
      orientation: 'landscape',
      minSdk: 29,
      targetSdk: 34,
      fullscreen: 'immersive',
      iconSpriteId: null,
      splashSpriteId: null,
      splashBgColor: '#1a1a3a',
    },
    controls: {
      left: { x: 4, y: 70, w: 14, h: 14, spriteId: null },
      right: { x: 22, y: 70, w: 14, h: 14, spriteId: null },
      sprint: { x: 36, y: 70, w: 14, h: 14, spriteId: null },
      jump: { x: 78, y: 58, w: 17, h: 17, spriteId: null },
      attack: { x: 78, y: 40, w: 15, h: 15, spriteId: null },
      joystick: { x: 5, y: 55, w: 28, h: 28, spriteId: null },
    },
  };
}

export function generateSprite(size = 'normal') {
  const { w, h } = SPR_SIZES[size] || SPR_SIZES.normal;
  const pixels = new Array(w * h).fill('#00000000');
  return {
    id: generateId(),
    name: 'sprite_' + (Math.random().toString(36).slice(2, 6)),
    size,
    w,
    h,
    pixels,
    frames: [{ id: generateId(), name: 'frame_1', pixels: [...pixels] }],
    createdAt: new Date().toISOString(),
  };
}

export function generateObject(type = 'solid') {
  return {
    id: generateId(),
    name: 'obj_' + (Math.random().toString(36).slice(2, 6)),
    type,
    spriteId: null,
    w: 32,
    h: 32,
    x: 0,
    y: 0,
    solid: type === 'solid' || type === 'platform',
    gravity: type === 'player' || type === 'enemy' || type === 'monster' || type === 'npc',
    color: '#888888',
    speed: 2.3,
    health: 100,
    maxHealth: 100,
    anim_idle: null,
    anim_walk: null,
    anim_run: null,
    anim_jump: null,
    anim_attack: null,
    anim_die: null,
    anim_hurt: null,
    animationSpeed: 8,
    frameDurationMs: 125,
    animEffect: 'none',
    animEffectSpeed: 5,
    facing: 1,
    movementMode: 'platformer',
    attackDamage: 10,
    scoreValue: 0,
    collectableScore: 100,
    lightRadius: 150,
    lightIntensity: 1,
    lightColor: '#ffcc66',
    flicker: false,
    mergeBackground: false,
    events: [],
    createdAt: new Date().toISOString(),
  };
}

export function generateLevel(name = 'Level 1') {
  return {
    id: generateId(),
    name,
    type: 'normal',
    w: 800,
    h: 480,
    bgColor: '#1a1a3a',
    bgGradient: false,
    bgGradientStart: '#000000',
    bgGradientEnd: '#ffffff',
    bgGradientType: 'vertical',
    instances: [],
    lighting: {
      enabled: false,
      ambientColor: '#0a0a20',
      darkness: 70,
      shadows: true,
      shader: 'none',
      shaderColor: '#3399ff',
      shaderIntensity: 40,
    },
    levelMovementMode: 'inherit',
    createdAt: new Date().toISOString(),
  };
}
