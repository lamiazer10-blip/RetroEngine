// AsyncStorage wrapper replacing localStorage
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEYS = {
  PROJECTS: 'retro_projects',
  CURRENT_PROJECT_ID: 'retro_current_project_id',
  USER_ID: 'retro_user_id',
  PEER_ID: 'retro_peer_id',
  APP_SETTINGS: 'retro_app_settings',
};

export async function getItem(key) {
  try {
    const value = await AsyncStorage.getItem(key);
    return value ? JSON.parse(value) : null;
  } catch (e) {
    console.warn('Storage getItem error:', key, e);
    return null;
  }
}

export async function setItem(key, value) {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('Storage setItem error:', key, e);
  }
}

export async function removeItem(key) {
  try {
    await AsyncStorage.removeItem(key);
  } catch (e) {
    console.warn('Storage removeItem error:', key, e);
  }
}

// Project storage
export async function loadProjects() {
  const projects = await getItem(STORAGE_KEYS.PROJECTS);
  return projects || [];
}

export async function saveProjects(projects) {
  await setItem(STORAGE_KEYS.PROJECTS, projects);
}

export async function getCurrentProjectId() {
  return await getItem(STORAGE_KEYS.CURRENT_PROJECT_ID);
}

export async function setCurrentProjectId(id) {
  await setItem(STORAGE_KEYS.CURRENT_PROJECT_ID, id);
}

// User identity
export async function getUserId() {
  let id = await getItem(STORAGE_KEYS.USER_ID);
  if (!id) {
    id = String(Math.floor(100000 + Math.random() * 900000));
    await setItem(STORAGE_KEYS.USER_ID, id);
  }
  return id;
}

export async function getSavedPeer() {
  return (await getItem(STORAGE_KEYS.PEER_ID)) || '';
}

export async function setSavedPeer(id) {
  await setItem(STORAGE_KEYS.PEER_ID, id);
}

// App settings
export async function loadAppSettings() {
  const defaults = { autoSave: true, soundEnabled: true, showGrid: true };
  const saved = await getItem(STORAGE_KEYS.APP_SETTINGS);
  return { ...defaults, ...saved };
}

export async function saveAppSettings(settings) {
  await setItem(STORAGE_KEYS.APP_SETTINGS, settings);
}

export default {
  getItem,
  setItem,
  removeItem,
  loadProjects,
  saveProjects,
  getCurrentProjectId,
  setCurrentProjectId,
  getUserId,
  getSavedPeer,
  setSavedPeer,
  loadAppSettings,
  saveAppSettings,
  STORAGE_KEYS,
};
