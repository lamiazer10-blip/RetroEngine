// Global project state — replaces the GC object in the web engine
import { generateProject } from '../utils/engineData';
import * as storage from './storage';

class ProjectManager {
  constructor() {
    this.project = null;
    this.projects = [];
    this.currentObjectId = null;
    this.currentSpriteId = null;
    this.currentLevelId = null;
    this.currentSongId = null;
    this._pendingProjectType = 'platformer';
    this._listeners = [];
  }

  subscribe(fn) {
    this._listeners.push(fn);
    return () => {
      this._listeners = this._listeners.filter(l => l !== fn);
    };
  }

  _notify() {
    this._listeners.forEach(fn => fn(this.project));
  }

  async init() {
    this.projects = await storage.loadProjects();
    const currentId = await storage.getCurrentProjectId();
    if (currentId) {
      this.project = this.projects.find(p => p.id === currentId) || null;
    }
    this._notify();
  }

  async createProject(title, type = 'platformer') {
    const project = generateProject();
    project.title = title;
    project.type = type;
    project.projectType = type;
    this.project = project;
    this.projects.push(project);
    await this.save();
    return project;
  }

  async openProject(id) {
    const project = this.projects.find(p => p.id === id);
    if (project) {
      this.project = { ...project };
      await storage.setCurrentProjectId(id);
      this._notify();
    }
    return this.project;
  }

  async saveProject() {
    if (!this.project) { return; }
    this.project.updatedAt = new Date().toISOString();
    this.project.version = (this.project.version || 0) + 1;
    const idx = this.projects.findIndex(p => p.id === this.project.id);
    if (idx >= 0) {
      this.projects[idx] = { ...this.project };
    } else {
      this.projects.push({ ...this.project });
    }
    await storage.saveProjects(this.projects);
    await storage.setCurrentProjectId(this.project.id);
    this._notify();
  }

  async deleteProject(id) {
    this.projects = this.projects.filter(p => p.id !== id);
    if (this.project && this.project.id === id) {
      this.project = null;
      await storage.setCurrentProjectId(null);
    }
    await storage.saveProjects(this.projects);
    this._notify();
  }

  // Sprite CRUD
  addSprite(sprite) {
    if (!this.project) { return null; }
    this.project.sprites = this.project.sprites || [];
    this.project.sprites.push(sprite);
    this.currentSpriteId = sprite.id;
    return sprite;
  }

  updateSprite(id, updates) {
    if (!this.project) { return; }
    const i = (this.project.sprites || []).findIndex(s => s.id === id);
    if (i >= 0) { this.project.sprites[i] = { ...this.project.sprites[i], ...updates }; }
  }

  deleteSprite(id) {
    if (!this.project) { return; }
    this.project.sprites = (this.project.sprites || []).filter(s => s.id !== id);
    if (this.currentSpriteId === id) { this.currentSpriteId = null; }
  }

  getSprite(id) {
    return (this.project?.sprites || []).find(s => s.id === id) || null;
  }

  // Object CRUD
  addObject(obj) {
    if (!this.project) { return null; }
    this.project.objects = this.project.objects || [];
    this.project.objects.push(obj);
    this.currentObjectId = obj.id;
    return obj;
  }

  updateObject(id, updates) {
    if (!this.project) { return; }
    const i = (this.project.objects || []).findIndex(o => o.id === id);
    if (i >= 0) { this.project.objects[i] = { ...this.project.objects[i], ...updates }; }
  }

  deleteObject(id) {
    if (!this.project) { return; }
    this.project.objects = (this.project.objects || []).filter(o => o.id !== id);
    if (this.currentObjectId === id) { this.currentObjectId = null; }
  }

  getObject(id) {
    return (this.project?.objects || []).find(o => o.id === id) || null;
  }

  // Level CRUD
  addLevel(level) {
    if (!this.project) { return null; }
    this.project.levels = this.project.levels || [];
    this.project.levels.push(level);
    this.currentLevelId = level.id;
    return level;
  }

  updateLevel(id, updates) {
    if (!this.project) { return; }
    const i = (this.project.levels || []).findIndex(l => l.id === id);
    if (i >= 0) { this.project.levels[i] = { ...this.project.levels[i], ...updates }; }
  }

  deleteLevel(id) {
    if (!this.project) { return; }
    this.project.levels = (this.project.levels || []).filter(l => l.id !== id);
    if (this.currentLevelId === id) { this.currentLevelId = null; }
  }

  getLevel(id) {
    return (this.project?.levels || []).find(l => l.id === id) || null;
  }

  // Game settings
  getGameSettings() {
    return this.project?.gameSettings || {};
  }

  updateGameSettings(updates) {
    if (!this.project) { return; }
    this.project.gameSettings = { ...this.project.gameSettings, ...updates };
  }

  // Export settings
  getExportSettings() {
    return this.project?.exportSettings || {};
  }

  updateExportSettings(updates) {
    if (!this.project) { return; }
    this.project.exportSettings = { ...this.project.exportSettings, ...updates };
  }

  async save() {
    await this.saveProject();
  }

  getStats() {
    const p = this.project;
    if (!p) { return { sprites: 0, objects: 0, levels: 0, songs: 0 }; }
    return {
      sprites: (p.sprites || []).length,
      objects: (p.objects || []).length,
      levels: (p.levels || []).length,
      songs: (p.songs || []).length,
    };
  }

  getProjectType() {
    return this.project?.projectType || this.project?.type || 'platformer';
  }
}

export const PM = new ProjectManager();
export default PM;
