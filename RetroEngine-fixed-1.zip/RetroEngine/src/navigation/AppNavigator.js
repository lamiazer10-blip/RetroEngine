import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StyleSheet } from 'react-native';

import IntroScreen from '../screens/IntroScreen';
import MainMenuScreen from '../screens/MainMenuScreen';
import CreateSelectScreen from '../screens/CreateSelectScreen';
import EnterTitleScreen from '../screens/EnterTitleScreen';
import ProjectTypeScreen from '../screens/ProjectTypeScreen';
import DashboardScreen from '../screens/DashboardScreen';
import SpritesScreen from '../screens/SpritesScreen';
import SpriteEditorScreen from '../screens/SpriteEditorScreen';
import ObjectsScreen from '../screens/ObjectsScreen';
import ObjectEditorScreen from '../screens/ObjectEditorScreen';
import LevelsScreen from '../screens/LevelsScreen';
import LevelEditorScreen from '../screens/LevelEditorScreen';
import LevelSettingsScreen from '../screens/LevelSettingsScreen';
import GameSettingsScreen from '../screens/GameSettingsScreen';
import ExportScreen from '../screens/ExportScreen';
import PlayGameScreen from '../screens/PlayGameScreen';
import PlaySelectScreen from '../screens/PlaySelectScreen';
import AppSettingsScreen from '../screens/AppSettingsScreen';
import OpenProjectScreen from '../screens/OpenProjectScreen';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    <GestureHandlerRootView style={styles.root}>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Intro"
          screenOptions={{
            headerShown: false,
            animation: 'slide_from_right',
            contentStyle: { backgroundColor: '#1e1e22' },
          }}>
          <Stack.Screen name="Intro" component={IntroScreen} />
          <Stack.Screen name="MainMenu" component={MainMenuScreen} />
          <Stack.Screen name="CreateSelect" component={CreateSelectScreen} />
          <Stack.Screen name="EnterTitle" component={EnterTitleScreen} />
          <Stack.Screen name="ProjectType" component={ProjectTypeScreen} />
          <Stack.Screen name="Dashboard" component={DashboardScreen} />
          <Stack.Screen name="Sprites" component={SpritesScreen} />
          <Stack.Screen name="SpriteEditor" component={SpriteEditorScreen} />
          <Stack.Screen name="Objects" component={ObjectsScreen} />
          <Stack.Screen name="ObjectEditor" component={ObjectEditorScreen} />
          <Stack.Screen name="Levels" component={LevelsScreen} />
          <Stack.Screen name="LevelEditor" component={LevelEditorScreen} />
          <Stack.Screen name="LevelSettings" component={LevelSettingsScreen} />
          <Stack.Screen name="GameSettings" component={GameSettingsScreen} />
          <Stack.Screen name="Export" component={ExportScreen} />
          <Stack.Screen name="PlayGame" component={PlayGameScreen} />
          <Stack.Screen name="PlaySelect" component={PlaySelectScreen} />
          <Stack.Screen name="AppSettings" component={AppSettingsScreen} />
          <Stack.Screen name="OpenProject" component={OpenProjectScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
});
